/**
 * RoomMuse AR — Integration for roommusestudio.com
 * 
 * Drop this script (along with roommuse-ar-sdk.js and qrcode.min.js) into
 * the mock website to add AR buttons to every product.
 * 
 * ──────────────────────────────────────────────────────────────────
 * HOW TO INTEGRATE (2 options)
 * ──────────────────────────────────────────────────────────────────
 * 
 * OPTION A — Data attributes (simplest, no JS needed per product)
 * ----------------------------------------------------------------
 * Add these scripts to your <head> or before </body>:
 *
 *   <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
 *   <script src="roommuse-ar-sdk.js"></script>
 *   <script src="roommuse-integration.js"></script>
 *
 * Then on each product card/page, add a container with:
 *
 *   <div data-roommuse-item="ITEM_ID_FROM_CSV"></div>
 *
 * The SDK auto-fetches the 3D model from the backend and injects a
 * "View in AR" button. The ITEM_ID should match the 'id' column
 * from Angela's CSV.
 *
 * Optional attributes:
 *   data-roommuse-style="icon"     → compact floating icon instead of button
 *   data-roommuse-label="Try AR"   → custom button text
 *   data-roommuse-size="small"     → smaller button variant
 *
 * 
 * OPTION B — Programmatic (more control)
 * ----------------------------------------------------------------
 * See the examples below — call sdk.createARButtonFromId() for each
 * product and append the returned button wherever you want.
 *
 * ──────────────────────────────────────────────────────────────────
 */

(async function () {
  'use strict';

  // ── Configuration ────────────────────────────────────────
  const CONFIG = {
    // Backend API where 3D models are stored
    apiBase: 'https://ar-backend-563656133641.us-central1.run.app',
    // AR viewer app (QR codes link here)
    arViewerUrl: 'https://ec-design.vercel.app',
    // QR code size in the modal
    qrCodeSize: 260,
  };

  // ── Wait for DOM ─────────────────────────────────────────
  if (document.readyState === 'loading') {
    await new Promise(r => document.addEventListener('DOMContentLoaded', r));
  }

  // ── Initialize SDK ───────────────────────────────────────
  if (typeof RoomMuseAR === 'undefined') {
    console.error('[RoomMuse Integration] roommuse-ar-sdk.js not loaded. Include it before this script.');
    return;
  }

  const sdk = new RoomMuseAR(CONFIG);

  // Init with auto-inject: scans for data-roommuse-item elements
  await sdk.init({ autoInject: true });

  // ── Expose globally for programmatic use ─────────────────
  window.roomMuseSDK = sdk;

  // ──────────────────────────────────────────────────────────
  // PROGRAMMATIC EXAMPLES (use in console or your own scripts)
  // ──────────────────────────────────────────────────────────
  //
  // // Fetch an item and create a button
  // const btn = await window.roomMuseSDK.createARButtonFromId('chair-001');
  // document.querySelector('.product-actions').appendChild(btn);
  //
  // // Fetch all items from the backend
  // const items = await window.roomMuseSDK.fetchAllItems();
  // console.log(items);
  //
  // // Generate a QR code into a specific container
  // await window.roomMuseSDK.generateQRCodeFromId('sofa-002', 'my-qr-div');
  //

})();
