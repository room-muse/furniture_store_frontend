/**
 * RoomMuse AR SDK v2.0.0
 * 
 * Fetches 3D models from the RoomMuse backend and generates QR codes
 * linking to the AR viewer for mobile AR placement.
 *
 * Backend: https://ar-backend-563656133641.us-central1.run.app
 * AR Viewer: https://ec-design.vercel.app
 *
 * Usage:
 *   const sdk = new RoomMuseAR();
 *   await sdk.init();
 *
 *   // Option A: Auto-fetch model from backend by item ID
 *   const btn = await sdk.createARButtonFromId('item-123');
 *   document.getElementById('container').appendChild(btn);
 *
 *   // Option B: Manual model data (legacy)
 *   const btn2 = sdk.createARButton({ name: 'Chair', modelUrl: '...' });
 */

class RoomMuseAR {
  constructor(config = {}) {
    this.apiBase = config.apiBase || 'https://ar-backend-563656133641.us-central1.run.app';
    this.arViewerUrl = config.arViewerUrl || 'https://ec-design.vercel.app';
    this.qrCodeSize = config.qrCodeSize || 260;
    this.theme = config.theme || 'default'; // 'default' | 'dark' | 'minimal'
    this._cache = new Map(); // cache fetched items
  }

  // ─── Backend API ─────────────────────────────────────────

  /**
   * Fetch item data (including 3D model URL) from the backend
   * @param {string} itemId - The item ID from the database
   * @returns {Promise<Object>} Item data with modelUrl, name, category, dimensions, etc.
   */
  async fetchItem(itemId) {
    // Return cached if available
    if (this._cache.has(itemId)) {
      return this._cache.get(itemId);
    }

    const url = `${this.apiBase}/items/${encodeURIComponent(itemId)}`;

    try {
      const res = await fetch(url);
      if (!res.ok) {
        throw new Error(`Failed to fetch item ${itemId}: ${res.status} ${res.statusText}`);
      }

      const data = await res.json();
      // Normalize the response — handle different possible field names
      const item = {
        id: data.id || itemId,
        name: data.name || data.item_name || 'Furniture',
        category: data.category || data.type || 'furniture',
        modelUrl: data.modelUrl || data.model_url || data.glb_url || data.model || null,
        imageUrl: data.imageUrl || data.image_url || data.thumbnail || null,
        dimensions: {
          length: data.length || data.dimensions?.length || null,
          width: data.width || data.dimensions?.width || null,
          height: data.height || data.dimensions?.height || null,
        },
        // Pass through any extra fields
        _raw: data
      };

      this._cache.set(itemId, item);
      return item;

    } catch (err) {
      console.error(`[RoomMuse AR] Error fetching item ${itemId}:`, err);
      throw err;
    }
  }

  /**
   * Fetch all items from the backend
   * @returns {Promise<Array>} Array of item objects
   */
  async fetchAllItems() {
    try {
      const res = await fetch(`${this.apiBase}/items`);
      if (!res.ok) {
        throw new Error(`Failed to fetch items: ${res.status} ${res.statusText}`);
      }

      const data = await res.json();
      const items = Array.isArray(data) ? data : (data.items || data.results || []);

      // Normalize and cache each item
      return items.map(raw => {
        const item = {
          id: raw.id || raw.item_id,
          name: raw.name || raw.item_name || 'Furniture',
          category: raw.category || raw.type || 'furniture',
          modelUrl: raw.modelUrl || raw.model_url || raw.glb_url || raw.model || null,
          imageUrl: raw.imageUrl || raw.image_url || raw.thumbnail || null,
          dimensions: {
            length: raw.length || raw.dimensions?.length || null,
            width: raw.width || raw.dimensions?.width || null,
            height: raw.height || raw.dimensions?.height || null,
          },
          _raw: raw
        };
        if (item.id) this._cache.set(String(item.id), item);
        return item;
      });
    } catch (err) {
      console.error('[RoomMuse AR] Error fetching all items:', err);
      throw err;
    }
  }

  // ─── AR Link Generation ──────────────────────────────────

  /**
   * Generate AR viewing link for a 3D model
   * @param {Object} modelData - Must contain modelUrl and optionally name, type
   */
  generateARLink(modelData) {
    if (modelData.modelUrl) {
      const params = new URLSearchParams({
        model: modelData.modelUrl,
        name: modelData.name || 'furniture',
        type: modelData.category || modelData.type || 'furniture'
      });

      // Add dimensions if available (for accurate AR placement)
      if (modelData.dimensions) {
        if (modelData.dimensions.length) params.set('length', modelData.dimensions.length);
        if (modelData.dimensions.width) params.set('width', modelData.dimensions.width);
        if (modelData.dimensions.height) params.set('height', modelData.dimensions.height);
      }

      return `${this.arViewerUrl}?${params.toString()}`;
    }
    return this.arViewerUrl;
  }

  /**
   * Generate AR link by fetching item from backend first
   * @param {string} itemId
   * @returns {Promise<string>} The AR URL
   */
  async generateARLinkFromId(itemId) {
    const item = await this.fetchItem(itemId);
    return this.generateARLink(item);
  }

  // ─── QR Code ─────────────────────────────────────────────

  /**
   * Generate QR code into a container element
   */
  generateQRCode(modelData, containerId) {
    const arUrl = this.generateARLink(modelData);
    const container = typeof containerId === 'string'
      ? document.getElementById(containerId)
      : containerId;

    if (!container) throw new Error(`Container not found: ${containerId}`);
    container.innerHTML = '';

    const qr = new QRCode(container, {
      text: arUrl,
      width: this.qrCodeSize,
      height: this.qrCodeSize,
      colorDark: '#1a1a2e',
      colorLight: '#ffffff',
      correctLevel: QRCode.CorrectLevel.H
    });

    return { qrCode: qr, url: arUrl };
  }

  /**
   * Generate QR code by item ID (fetches from backend first)
   */
  async generateQRCodeFromId(itemId, containerId) {
    const item = await this.fetchItem(itemId);
    return this.generateQRCode(item, containerId);
  }

  // ─── Device Detection ────────────────────────────────────

  isMobile() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  }

  isIOS() {
    return /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
  }

  // ─── UI Components ─────────────────────────────────────────

  /**
   * Create an AR button from item data (synchronous — model data already known)
   */
  createARButton(modelData, options = {}) {
    const btn = document.createElement('button');
    btn.className = `rmar-button ${options.size === 'small' ? 'rmar-button--sm' : ''}`;
    btn.innerHTML = `
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
        <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
        <line x1="12" y1="22.08" x2="12" y2="12"/>
      </svg>
      <span>${options.label || 'View in AR'}</span>
    `;

    btn.addEventListener('click', () => {
      if (this.isMobile()) {
        window.location.href = this.generateARLink(modelData);
      } else {
        this._openModal(modelData);
      }
    });

    return btn;
  }

  /**
   * Create an AR button by item ID (async — fetches from backend)
   * @param {string} itemId
   * @param {Object} options
   * @returns {Promise<HTMLElement>}
   */
  async createARButtonFromId(itemId, options = {}) {
    const item = await this.fetchItem(itemId);
    return this.createARButton(item, options);
  }

  /**
   * Create a floating AR icon button (compact, for overlays)
   */
  createARIcon(modelData) {
    const btn = document.createElement('button');
    btn.className = 'rmar-icon';
    btn.title = 'View in AR';
    btn.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
        <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
        <line x1="12" y1="22.08" x2="12" y2="12"/>
      </svg>
    `;

    btn.addEventListener('click', () => {
      if (this.isMobile()) {
        window.location.href = this.generateARLink(modelData);
      } else {
        this._openModal(modelData);
      }
    });

    return btn;
  }

  /**
   * Create AR icon by item ID (async)
   */
  async createARIconFromId(itemId) {
    const item = await this.fetchItem(itemId);
    return this.createARIcon(item);
  }

  // ─── Auto-inject: scan page for data-roommuse-item attributes ──

  /**
   * Automatically scan the page for elements with data-roommuse-item="<itemId>"
   * and inject AR buttons into them.
   * 
   * Usage: Add data-roommuse-item="<id>" to any element on the mock website.
   *        The SDK will fetch the model and inject a "View in AR" button.
   *
   * Optional attributes:
   *   data-roommuse-style="button" | "icon" (default: "button")
   *   data-roommuse-label="Custom label"
   */
  async autoInject() {
    const elements = document.querySelectorAll('[data-roommuse-item]');
    if (elements.length === 0) {
      console.log('[RoomMuse AR] No data-roommuse-item elements found on page.');
      return [];
    }

    const results = [];

    for (const el of elements) {
      const itemId = el.getAttribute('data-roommuse-item');
      const style = el.getAttribute('data-roommuse-style') || 'button';
      const label = el.getAttribute('data-roommuse-label');

      try {
        const item = await this.fetchItem(itemId);
        let widget;

        if (style === 'icon') {
          widget = this.createARIcon(item);
        } else {
          widget = this.createARButton(item, {
            label: label || 'View in AR',
            size: el.getAttribute('data-roommuse-size') || ''
          });
        }

        el.appendChild(widget);
        results.push({ itemId, item, element: el, widget });

      } catch (err) {
        console.warn(`[RoomMuse AR] Failed to inject AR for item ${itemId}:`, err);
        results.push({ itemId, error: err, element: el });
      }
    }

    console.log(`[RoomMuse AR] Auto-injected ${results.filter(r => !r.error).length}/${elements.length} AR widgets`);
    return results;
  }

  // ─── Modal ─────────────────────────────────────────────────

  _openModal(modelData) {
    const arUrl = this.generateARLink(modelData);

    const overlay = document.createElement('div');
    overlay.className = 'rmar-overlay';
    overlay.innerHTML = `
      <div class="rmar-modal">
        <button class="rmar-modal__close" aria-label="Close">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>

        <div class="rmar-modal__icon">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
            <polyline points="3.27 6.96 12 12.01 20.73 6.96"/>
            <line x1="12" y1="22.08" x2="12" y2="12"/>
          </svg>
        </div>

        <h2 class="rmar-modal__title">View in Your Space</h2>
        <p class="rmar-modal__subtitle">Scan the QR code with your phone camera to place <strong>${modelData.name || 'this item'}</strong> in AR</p>

        ${modelData.dimensions && modelData.dimensions.length ?
          `<p class="rmar-modal__dims">${modelData.dimensions.length}m × ${modelData.dimensions.width}m × ${modelData.dimensions.height}m</p>` : ''}

        <div class="rmar-modal__qr" id="rmar-qr-target"></div>

        <div class="rmar-modal__steps">
          <div class="rmar-step">
            <div class="rmar-step__num">1</div>
            <span>Scan QR</span>
          </div>
          <div class="rmar-step__arrow">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
          </div>
          <div class="rmar-step">
            <div class="rmar-step__num">2</div>
            <span>Opens AR</span>
          </div>
          <div class="rmar-step__arrow">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
          </div>
          <div class="rmar-step">
            <div class="rmar-step__num">3</div>
            <span>Place it</span>
          </div>
        </div>

        <a class="rmar-modal__link" href="${arUrl}" target="_blank" rel="noopener">
          Or open directly on mobile &rarr;
        </a>
      </div>
    `;

    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('rmar-overlay--visible'));

    // Generate QR
    this.generateQRCode(modelData, 'rmar-qr-target');

    // Close handlers
    const close = () => {
      overlay.classList.remove('rmar-overlay--visible');
      setTimeout(() => overlay.remove(), 300);
    };
    overlay.querySelector('.rmar-modal__close').addEventListener('click', close);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) close();
    });
    document.addEventListener('keydown', function handler(e) {
      if (e.key === 'Escape') { close(); document.removeEventListener('keydown', handler); }
    });
  }

  // ─── Styles ────────────────────────────────────────────────

  _injectStyles() {
    if (document.getElementById('rmar-styles')) return;
    const style = document.createElement('style');
    style.id = 'rmar-styles';
    style.textContent = `
      /* ── Button ── */
      .rmar-button {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 12px 22px; border: none; border-radius: 10px;
        background: #1a1a2e; color: #fff;
        font: 600 15px/1 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        cursor: pointer; transition: all .2s ease;
        box-shadow: 0 2px 8px rgba(26,26,46,.25);
      }
      .rmar-button:hover { background: #2d2d4a; transform: translateY(-1px); box-shadow: 0 4px 16px rgba(26,26,46,.35); }
      .rmar-button:active { transform: translateY(0); }
      .rmar-button--sm { padding: 8px 16px; font-size: 13px; border-radius: 8px; }
      .rmar-button--sm svg { width: 14px; height: 14px; }

      /* ── Icon Button ── */
      .rmar-icon {
        display: inline-flex; align-items: center; justify-content: center;
        width: 44px; height: 44px; border: none; border-radius: 12px;
        background: #1a1a2e; color: #fff; cursor: pointer;
        transition: all .2s ease; box-shadow: 0 2px 8px rgba(26,26,46,.25);
      }
      .rmar-icon:hover { background: #2d2d4a; transform: scale(1.05); }

      /* ── Overlay ── */
      .rmar-overlay {
        position: fixed; inset: 0; z-index: 99999;
        display: flex; align-items: center; justify-content: center;
        background: rgba(10,10,20,.6); backdrop-filter: blur(6px);
        opacity: 0; transition: opacity .3s ease; padding: 20px;
      }
      .rmar-overlay--visible { opacity: 1; }

      /* ── Modal ── */
      .rmar-modal {
        position: relative; background: #fff; border-radius: 20px;
        padding: 44px 40px 36px; max-width: 440px; width: 100%;
        box-shadow: 0 24px 64px rgba(0,0,0,.25);
        transform: translateY(12px) scale(.97);
        transition: transform .3s ease;
        text-align: center;
      }
      .rmar-overlay--visible .rmar-modal { transform: translateY(0) scale(1); }

      .rmar-modal__close {
        position: absolute; top: 14px; right: 14px;
        width: 34px; height: 34px; border: none; border-radius: 50%;
        background: #f0f0f4; color: #666; cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: all .15s;
      }
      .rmar-modal__close:hover { background: #e4e4ea; color: #333; }

      .rmar-modal__icon {
        display: inline-flex; align-items: center; justify-content: center;
        width: 72px; height: 72px; border-radius: 18px;
        background: linear-gradient(135deg, #eef0ff 0%, #f5e6ff 100%);
        color: #5a4fcf; margin-bottom: 20px;
      }

      .rmar-modal__title {
        font: 700 22px/1.2 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        color: #1a1a2e; margin: 0 0 8px;
      }
      .rmar-modal__subtitle {
        font: 400 14px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        color: #6b6b80; margin: 0 0 8px;
      }
      .rmar-modal__subtitle strong { color: #1a1a2e; font-weight: 600; }

      .rmar-modal__dims {
        font: 500 12px/1 -apple-system, sans-serif;
        color: #999; margin: 0 0 24px;
        letter-spacing: .02em;
      }

      .rmar-modal__qr {
        display: flex; justify-content: center;
        padding: 20px; background: #fafafc; border-radius: 14px;
        margin-bottom: 28px;
      }
      .rmar-modal__qr img { border-radius: 6px; }

      /* ── Steps ── */
      .rmar-modal__steps {
        display: flex; align-items: center; justify-content: center; gap: 10px;
        margin-bottom: 24px;
      }
      .rmar-step {
        display: flex; flex-direction: column; align-items: center; gap: 6px;
      }
      .rmar-step__num {
        width: 28px; height: 28px; border-radius: 50%;
        background: #1a1a2e; color: #fff;
        font: 600 13px/28px -apple-system, sans-serif;
        text-align: center;
      }
      .rmar-step span { font: 500 12px/1 -apple-system, sans-serif; color: #6b6b80; }
      .rmar-step__arrow { color: #ccc; margin-top: -14px; }

      .rmar-modal__link {
        display: inline-block; font: 500 13px/1 -apple-system, sans-serif;
        color: #5a4fcf; text-decoration: none;
        padding: 10px 18px; border-radius: 8px;
        transition: background .15s;
      }
      .rmar-modal__link:hover { background: #f4f0ff; }

      @media (max-width: 500px) {
        .rmar-modal { padding: 32px 24px 28px; }
        .rmar-modal__steps { gap: 6px; }
      }
    `;
    document.head.appendChild(style);
  }

  // ─── Init ──────────────────────────────────────────────────

  /**
   * Initialize the SDK: injects styles, optionally auto-injects AR widgets.
   * @param {Object} options - { autoInject: true } to auto-scan the page
   */
  async init(options = {}) {
    this._injectStyles();
    console.log('%c✓ RoomMuse AR SDK v2.0 ready', 'color:#5a4fcf;font-weight:600');
    console.log(`%c  API: ${this.apiBase}`, 'color:#888');
    console.log(`%c  AR Viewer: ${this.arViewerUrl}`, 'color:#888');

    if (options.autoInject) {
      await this.autoInject();
    }

    return this;
  }
}

// Export for module and global usage
if (typeof module !== 'undefined' && module.exports) {
  module.exports = RoomMuseAR;
}
if (typeof window !== 'undefined') {
  window.RoomMuseAR = RoomMuseAR;
}
