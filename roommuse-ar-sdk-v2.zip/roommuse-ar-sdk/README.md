# RoomMuse AR SDK v2.0

AR furniture viewing SDK that **automatically fetches 3D models from the RoomMuse backend** and generates QR codes for mobile AR placement.

- **Backend API:** `https://ar-backend-563656133641.us-central1.run.app`
- **AR Viewer:** `https://ec-design.vercel.app`
- **GitHub Org:** [github.com/room-muse](https://github.com/room-muse)
- **Mock Website:** [roommusestudio.com](https://www.roommusestudio.com/)

---

## Files

```
roommuse-ar-sdk/
├── roommuse-ar-sdk.js         ← The SDK (include in your project)
├── roommuse-integration.js    ← Drop-in script for roommusestudio.com
├── demo.html                  ← Live demo (fetches products from backend)
└── README.md                  ← You're reading this
```

---

## What Changed from v1 → v2

| Feature | v1 | v2 |
|---------|----|----|
| Model URLs | Hardcoded per product | Auto-fetched from backend API |
| Backend integration | None | `fetchItem()`, `fetchAllItems()` |
| Data attributes | Not supported | `data-roommuse-item="<id>"` auto-injects AR |
| Dimensions | Not shown | Displayed in modal from CSV data |
| Caching | None | In-memory cache per session |

---

## Quick Start

### 1. Include dependencies

```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="roommuse-ar-sdk.js"></script>
```

### 2. Initialize

```javascript
const sdk = new RoomMuseAR({
  apiBase: 'https://ar-backend-563656133641.us-central1.run.app',
  arViewerUrl: 'https://ec-design.vercel.app'
});
await sdk.init();
```

### 3. Add AR to products

**Option A — By item ID (auto-fetches from backend):**
```javascript
const btn = await sdk.createARButtonFromId('chair-001');
document.getElementById('my-container').appendChild(btn);
```

**Option B — Data attributes (zero JS per product):**
```html
<div data-roommuse-item="chair-001"></div>
<div data-roommuse-item="sofa-002" data-roommuse-style="icon"></div>
```
Then initialize with auto-inject:
```javascript
await sdk.init({ autoInject: true });
```

**Option C — Manual model data (legacy v1 style):**
```javascript
const btn = sdk.createARButton({
  name: 'Office Chair',
  modelUrl: 'https://cdn.example.com/chair.glb',
  type: 'furniture'
});
```

---

## Integration with roommusestudio.com

### Step 1: Add scripts to the website

Add before `</body>`:

```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script src="roommuse-ar-sdk.js"></script>
<script src="roommuse-integration.js"></script>
```

### Step 2: Add AR containers to product cards

On each product, add a div with the item ID from the CSV:

```html
<!-- The item ID should match the 'id' column from Angela's CSV -->
<div data-roommuse-item="ITEM_ID_HERE"></div>
```

The SDK automatically:
1. Calls `GET /items/{item_id}` on the backend
2. Gets the auto-generated 3D model URL
3. Injects a "View in AR" button
4. On click (desktop): shows QR code modal
5. On click (mobile): opens AR viewer directly

### Optional data attributes

| Attribute | Values | Default | Description |
|-----------|--------|---------|-------------|
| `data-roommuse-item` | item ID | (required) | The ID from the CSV |
| `data-roommuse-style` | `button`, `icon` | `button` | Widget style |
| `data-roommuse-label` | any string | `View in AR` | Button text |
| `data-roommuse-size` | `small`, (empty) | normal | Button size |

---

## API Reference

### Constructor

```javascript
new RoomMuseAR({
  apiBase: 'https://ar-backend-563656133641.us-central1.run.app', // Backend URL
  arViewerUrl: 'https://ec-design.vercel.app',                    // AR viewer URL
  qrCodeSize: 260,                                                 // QR code pixel size
  theme: 'default'                                                  // 'default' | 'dark' | 'minimal'
})
```

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `init(options?)` | `Promise<this>` | Inject styles. `{ autoInject: true }` to auto-scan page. |
| `fetchItem(itemId)` | `Promise<Object>` | Fetch single item from backend |
| `fetchAllItems()` | `Promise<Array>` | Fetch all items from backend |
| `createARButton(data, opts?)` | `HTMLElement` | Create AR button (sync, data known) |
| `createARButtonFromId(id, opts?)` | `Promise<HTMLElement>` | Create AR button (async, fetches from API) |
| `createARIcon(data)` | `HTMLElement` | Create compact AR icon (sync) |
| `createARIconFromId(id)` | `Promise<HTMLElement>` | Create compact AR icon (async) |
| `generateARLink(data)` | `string` | Generate AR viewer URL |
| `generateARLinkFromId(id)` | `Promise<string>` | Generate AR URL (async) |
| `generateQRCode(data, containerId)` | `Object` | Render QR code into container |
| `generateQRCodeFromId(id, containerId)` | `Promise<Object>` | Render QR code (async) |
| `autoInject()` | `Promise<Array>` | Scan page for `data-roommuse-item` elements |

---

## Launch the Demo

```bash
cd roommuse-ar-sdk
python3 -m http.server 8000
# Open http://localhost:8000/demo.html
```

The demo fetches products live from the backend. If the API returns items, they appear as cards with AR buttons. If not, it shows a fallback error state.

---

## End-to-End Flow

```
Angela's CSV  →  Aditya uploads to backend  →  Backend generates 3D models
                                                         ↓
User on roommusestudio.com  →  SDK calls GET /items/{id}  →  Gets model URL
                                                         ↓
                              Desktop: QR modal  ←  AR button click  →  Mobile: direct AR
                                    ↓
                              Phone scans QR  →  ec-design.vercel.app?model=...  →  AR view
```
